// Copyright 2021, Pulumi Corporation.  All rights reserved.

package version

var Version string
