---
name: Default template
title: ''
labels: needs-triage

---

### Problem description

<!--Briefly describe the issue that you've found.
    For general questions, join us on https://pulumi-community.slack.com/. -->

- I saw an issue in the following Pulumi Program: <URL>

- I saw an issue in the following documentation: <URL>

- I had trouble finding the information that I needed: <URL>

- Other: <DETAILS>

### Errors & Logs

<!-- If there are any relevant error messages and logs that further describe the issue, please list them out.-->

### Affected product version(s)

<!-- If the issue is specific to a Pulumi product version, let us know which version(s). -->

### Reproducing the issue

<!-- If possible, please include a full Pulumi program tar'd or zipped up that reproduces the error. -->

### Suggestions for a fix

<!--If you have specific ideas about how we can fix this, let us know, or [create a pull request](https://github.com/pulumi/pulumi-eks/pull/new/. :) -->


<!-- To improve this template, edit the .github/ISSUE_TEMPLATE.md file -->
