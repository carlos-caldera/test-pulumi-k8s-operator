// Package v1alpha1 contains API Schema definitions for the pulumi v1alpha1 API group
// +k8s:deepcopy-gen=package,register
// +groupName=pulumi.com
package v1alpha1
