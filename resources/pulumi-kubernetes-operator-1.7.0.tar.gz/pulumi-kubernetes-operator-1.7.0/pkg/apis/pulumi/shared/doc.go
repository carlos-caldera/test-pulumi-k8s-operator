// Package shared contains shared schema definitions
// +k8s:deepcopy-gen=package
// +groupName=pulumi.com
package shared
