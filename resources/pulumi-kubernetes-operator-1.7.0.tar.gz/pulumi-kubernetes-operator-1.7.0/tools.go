// Copyright 2021, Pulumi Corporation.  All rights reserved.

// +build tools

// Place any runtime dependencies as imports in this file.
// Go modules will be forced to download and install them.
package tools
